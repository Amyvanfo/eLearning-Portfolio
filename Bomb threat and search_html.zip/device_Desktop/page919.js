if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton343.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj343inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_919_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1217&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 590px; top: 17px; width: 42px; height: 42px; z-index: 4; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"343",
	htmlId:		"tobj343",
	bInsAnc:	false,
	cwObj:		{
		"name":	"home",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page40.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[589.9999999999999,17.000000000000096,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":590,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1217&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1219\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1219&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1221\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1221&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1223\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1223&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"home","titleValue":"home"}
};
textbutton1050.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1050inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_919_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1225&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 652px; top: 17px; width: 42px; height: 42px; z-index: 5; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1050",
	htmlId:		"tobj1050",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btn2_exit",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkExitClose',actItem:function(){ {cleanupTitle('page1.html'); trivExitPage('ObjLayerActionExit()',false);} 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[651.9999999999999,17.000000000000092,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":652,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1225&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1227\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1227&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1229\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1229&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_919_40_1231\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_919_40_1231&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"btn2_exit","titleValue":"btn2_exit"}
};
image58.rcdData.att_Desktop = 
{
	innerHtml:	"<img id=\"tobj58Img\" src=\"images/image0002.png\" alt=\"Picture 8\" title=\"Picture 8\" style=\"border-radius: 0px; position: absolute; border-style: none; left: 0px; top: 0px; width: 137px; height: 37px;\">",
	cssText:	"visibility: inherit; position: absolute; left: 32px; top: 479px; width: 137px; height: 37px; z-index: 0; border-radius: 0px;",
	cssClasses:	"",
	id:		"58",
	htmlId:		"tobj58",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Picture 8"
	},
	objData:	{"a":[0,288,0,[32,479,137,37]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":32,"y":479,"width":137,"height":37}}
};
shape64.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj64inner\"><svg viewBox=\"0 0 720 82\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(360 41)\" style=\"\">\n	<path d=\"M 0 0 L 720 0 L 720 82 L 0 82 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(200, 16, 46); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-360, -41) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(360 41)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 2.13163e-12px; width: 720px; height: 82px; z-index: 1; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"64",
	htmlId:		"tobj64",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 7"
	},
	objData:	{"a":[0,288,0,[0,2.1316282072803006e-12,720,82]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":720,"height":82},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 7","titleValue":"Rectangle 7"}
};
og72.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og72",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape73.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj73inner\"><svg viewBox=\"0 0 683 77\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(341.5 38.5)\" style=\"\">\n	<path d=\"M 0 0 L 683 0 L 683 77 L 0 77 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(200, 16, 46); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-341.5, -38.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(341.5 38.5)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 1.44951e-12px; width: 683px; height: 77px; z-index: 2; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"73",
	htmlId:		"tobj73",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 8"
	},
	objData:	{"a":[0,288,0,[0,1.4495071809506044e-12,683,77]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":683,"height":77},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 8","titleValue":"Rectangle 8"}
};
text188.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 350px; min-height: 35px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 340px; min-height: 25px;\"><h1><p align=\"left\"><span style=\"font-family: Verdana, sans-serif; color: rgb(255, 255, 255); font-size: 16pt;\"><span class='VarCurrentPageName'>" +  VarCurrentPageName.getValueForDisplay() + "</span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 19px; top: 29px; width: 350px; height: 35px; z-index: 6;",
	cssClasses:	"",
	id:		"188",
	htmlId:		"tobj188",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,96,0,[19,29,350,35]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":19,"y":29,"width":350,"height":35},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text1036.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 552px; min-height: 71px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 542px; min-height: 61px;\"><p style=\"text-align: left; line-height: 1.25; margin-top: 0px; margin-bottom: 0px;\"><span style=\"color: rgb(0, 0, 0); font-family: \'Arial\',sans-serif; font-size: 12pt;\">Sorry, you did not get a passing score on the test. Please click the home button to review the content and try again.</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 51px; top: 129px; width: 552px; height: 71px; z-index: 3;",
	cssClasses:	"",
	id:		"1036",
	htmlId:		"tobj1036",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[0,32,0,[51,129,552,71]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":51,"y":129,"width":552,"height":71},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
rcdObj.rcdData.att_Desktop = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"normal","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	27
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/image0000.png","images/image0002.png","images/home.png","images/btn2_exit1049.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-image: url("images/image0000.png"); visibility: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","url(images/image0000.png)",720,540,1];
