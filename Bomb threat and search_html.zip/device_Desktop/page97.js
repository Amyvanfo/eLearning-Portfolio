if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton343.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj343inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_97_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1217&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 590px; top: 17px; width: 42px; height: 42px; z-index: 66; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"343",
	htmlId:		"tobj343",
	bInsAnc:	false,
	cwObj:		{
		"name":	"home",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page40.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[590,17.00000000000003,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":590,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1217&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1219\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1219&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1221\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1221&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1223\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1223&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"home","titleValue":"home"}
};
textbutton1050.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1050inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_97_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1225&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 652px; top: 17px; width: 42px; height: 42px; z-index: 67; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1050",
	htmlId:		"tobj1050",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btn2_exit",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkExitClose',actItem:function(){ {cleanupTitle('page1.html'); trivExitPage('ObjLayerActionExit()',false);} 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[652,17.00000000000003,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":652,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1225&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1227\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1227&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1229\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1229&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_40_1231\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_40_1231&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"btn2_exit","titleValue":"btn2_exit"}
};
textbutton333.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj333inner\"><svg viewBox=\"0 0 41 41\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(20.5 20.5)\" style=\"\">\n	<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_97_316_1241\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_316_1241&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(20.5 20.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 590px; top: 488px; width: 41px; height: 41px; z-index: 68; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"333",
	htmlId:		"tobj333",
	bInsAnc:	false,
	cwObj:		{
		"name":	"arrow2_back",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page83.html',false,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[590,488,41,41]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":590,"y":488,"width":41,"height":41},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_316_1241\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_316_1241&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_316_1243\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_316_1243&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_316_1245\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_316_1245&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_316_1247\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_316_1247&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"arrow2_back","titleValue":"arrow2_back"}
};
text188.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 350px; min-height: 35px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 340px; min-height: 25px;\"><h1><p align=\"left\"><span style=\"font-family: Verdana, sans-serif; color: rgb(255, 255, 255); font-size: 16pt;\"><span class='VarCurrentPageName'>" +  VarCurrentPageName.getValueForDisplay() + "</span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 19px; top: 29px; width: 350px; height: 35px; z-index: 69;",
	cssClasses:	"",
	id:		"188",
	htmlId:		"tobj188",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,96,0,[19,29,350,35]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":19,"y":29,"width":350,"height":35},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
shape1099.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1099inner\"><svg viewBox=\"0 0 720 68\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(360 34)\" style=\"\">\n	<path d=\"M 0 0 L 720 0 L 720 68 L 0 68 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(200, 16, 46); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-360, -34) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(360 34)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 8.52651e-14px; width: 720px; height: 68px; z-index: 0; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1099",
	htmlId:		"tobj1099",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 7"
	},
	objData:	{"a":[0,32,0,[0,8.526512829121202e-14,720,68]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":720,"height":68},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 7","titleValue":"Rectangle 7"}
};
og663.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og663",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
textbutton642.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj642inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_97_1265\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/arrow2_next.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_1265&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 652px; top: 487px; width: 42px; height: 42px; z-index: 1; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"642",
	htmlId:		"tobj642",
	bInsAnc:	false,
	cwObj:		{
		"name":	"special next",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page114.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33024,0,[652,487,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":652,"y":487,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_1265\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/arrow2_next.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_1265&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_1267\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/arrow2_next.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_1267&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_1269\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/arrow2_next.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_1269&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_97_1271\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/arrow2_next.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_97_1271&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"special next","titleValue":"special next"}
};
text647.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 227px; height: 130px;\"><div id=\"dCon3\" style=\"position: absolute; background-clip: content-box; left: 0px; top: 0px; height: 126px; width: 223px; border: 2px solid rgb(207, 42, 39);\"></div><div name=\"dCon2\" class=\"ttxt\" style=\"left: 7px; top: 7px; width: 213px; height: 116px;\"><p style=\"text-align:left\"><span style=\"font-family:Arial,sans-serif;font-size:12pt;color:#000000\">People may hear different things when a bomb threat is received. Just remember to add as much detail as you can as this will assist law enforcement.</span></p></div></div>",
	cssText:	"visibility: hidden; position: absolute; left: 444px; top: 331px; width: 227px; height: 130px; z-index: 2;",
	cssClasses:	"",
	id:		"647",
	htmlId:		"tobj647",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Answer text"
	},
	objData:	{"a":[0,0,0,[444,331,227,130]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":2,"lineStyle":0,"borderColor":"#cf2a27","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":444,"y":331,"width":227,"height":130},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
shape303.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj303inner\"><svg viewBox=\"0 0 666 412\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(333 206)\" style=\"\">\n	<path d=\"M 0 0 L 665 0 L 665 411 L 0 411 L 0 0 Z\" style=\"stroke: rgb(51, 51, 51); stroke-width: 1; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity:0;filter:alpha(opacity=0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-332.5, -205.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(333 206)\">\n		<text font-family=\"Calibri\" font-size=\"13.333333\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"4.2\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: hidden; position: absolute; left: 21.5px; top: 116.5px; width: 666px; height: 412px; z-index: 3; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"303",
	htmlId:		"tobj303",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 8"
	},
	objData:	{"a":[0,0,0,[21.499999999999943,116.50000000000009,666,412]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":22,"y":117,"width":666,"height":412},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 8","titleValue":"Rectangle 8"}
};
text254.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 668px; height: 49px; background-color: rgb(7, 55, 99);\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 658px; height: 39px;\"><p style=\"text-align:left\"><span style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(255, 255, 255);\">In the form below, check the boxes that describe what you heard in the call. </span></p>\n\n<p style=\"text-align:left\"><strong><span style=\"font-size: 12pt; font-family: Arial, sans-serif; color: rgb(255, 255, 255);\">Check at least one box in each column.</span></strong></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 24px; top: 68px; width: 668px; height: 49px; z-index: 4;",
	cssClasses:	"",
	id:		"254",
	htmlId:		"tobj254",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 1"
	},
	objData:	{"a":[0,32,0,[24,68,668,49]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":24,"y":68,"width":668,"height":49},"dwTextFlags":0,"bgColor":"#073763","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
qu255.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu255",
	bInsAnc:	undefined,
	cwObj:		{
				"crLineColor":	"",
				"questType":	14,
				"dwQuestFlags":	557067,
				"doImmFeedback":	32768,
				"maxAllowedAttempts":	1,
				"arrAns":	["\\u006E\\u006F\\u006E\\u0065\\u0020\\u006F\\u0066\\u0020\\u0074\\u0068\\u0065\\u0020\\u0061\\u0062\\u006F\\u0076\\u0065"],
				"correctFeedbackFunc":	"action255_1",
				"incorrectFeedbackFunc":	"action255_2",
				"attemptsFeedbackFunc":	"action255_3",
				"varQuest":	VarQuestion_255,
				"varAttempts":	VarTriQA_255
	},
	objData:	{"a":[0,32,0,[]]}
};
text260.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 183px; min-height: 21px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 183px; min-height: 21px;\"><p align=\"left\"><strong><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Threat Language</span></strong></p>\n</div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 452px; top: 134px; width: 183px; height: 21px; z-index: 5;",
	cssClasses:	"",
	id:		"260",
	htmlId:		"tobj260",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[452,134,183,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":452,"y":134,"width":183,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text261.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 86px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 86px; min-height: 21px;\"><label for=\"rad262\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Incoherent</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 481px; top: 165px; width: 86px; height: 21px; z-index: 6;",
	cssClasses:	"",
	id:		"261",
	htmlId:		"tobj261",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[481,165,86,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":481,"y":165,"width":86,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox262.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad262\" name=\"rad262\" value=\"Incoherent\" onclick=\"qu255.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 450px; top: 166px; width: 19px; height: 19px; z-index: 7;",
	cssClasses:	"",
	id:		"262",
	htmlId:		"tobj262",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[450,166,19,19]],"desktopRect":{"x":450,"y":166,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text263.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 116px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 116px; min-height: 21px;\"><label for=\"rad264\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Message read</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 481px; top: 193px; width: 116px; height: 21px; z-index: 8;",
	cssClasses:	"",
	id:		"263",
	htmlId:		"tobj263",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[481,193,116,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":481,"y":193,"width":116,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox264.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad264\" name=\"rad264\" value=\"Message read\" onclick=\"qu255.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 450px; top: 194px; width: 19px; height: 19px; z-index: 9;",
	cssClasses:	"",
	id:		"264",
	htmlId:		"tobj264",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[450,194,19,19]],"desktopRect":{"x":450,"y":194,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text265.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 127px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 127px; min-height: 21px;\"><label for=\"rad266\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Taped message</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 481px; top: 221px; width: 127px; height: 21px; z-index: 10;",
	cssClasses:	"",
	id:		"265",
	htmlId:		"tobj265",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[481,221,127,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":481,"y":221,"width":127,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox266.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad266\" name=\"rad266\" value=\"Taped message\" onclick=\"qu255.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 450px; top: 222px; width: 19px; height: 19px; z-index: 11;",
	cssClasses:	"",
	id:		"266",
	htmlId:		"tobj266",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[450,222,19,19]],"desktopRect":{"x":450,"y":222,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text267.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 70px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 70px; min-height: 21px;\"><label for=\"rad268\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Profane</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 481px; top: 249px; width: 70px; height: 21px; z-index: 12;",
	cssClasses:	"",
	id:		"267",
	htmlId:		"tobj267",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 4 text"
	},
	objData:	{"a":[0,32,0,[481,249,70,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":481,"y":249,"width":70,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox268.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad268\" name=\"rad268\" value=\"Profane\" onclick=\"qu255.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 450px; top: 250px; width: 19px; height: 19px; z-index: 13;",
	cssClasses:	"",
	id:		"268",
	htmlId:		"tobj268",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 4 button"
	},
	objData:	{"a":[0,32,0,[450,250,19,19]],"desktopRect":{"x":450,"y":250,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text269.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 138px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 138px; min-height: 21px;\"><label for=\"rad270\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">none of the above</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 481px; top: 277px; width: 138px; height: 21px; z-index: 14;",
	cssClasses:	"",
	id:		"269",
	htmlId:		"tobj269",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 5 text"
	},
	objData:	{"a":[0,32,0,[481,277,138,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":481,"y":277,"width":138,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox270.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad270\" name=\"rad270\" value=\"none of the above\" onclick=\"qu255.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 450px; top: 278px; width: 19px; height: 19px; z-index: 15;",
	cssClasses:	"",
	id:		"270",
	htmlId:		"tobj270",
	bInsAnc:	0,
	fieldsetId:	'fset255',
	cwObj:		{
		"name":	"Choice 5 button"
	},
	objData:	{"a":[0,32,0,[450,278,19,19]],"desktopRect":{"x":450,"y":278,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
qu194.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu194",
	bInsAnc:	undefined,
	cwObj:		{
				"crLineColor":	"",
				"questType":	14,
				"dwQuestFlags":	1,
				"doImmFeedback":	0,
				"maxAllowedAttempts":	0,
				"arrAns":	["\\u004D\\u0061\\u006C\\u0065"],
				"correctFeedbackFunc":	0,
				"incorrectFeedbackFunc":	0,
				"attemptsFeedbackFunc":	0,
				"varQuest":	VarQuestion_194
	},
	objData:	{"a":[0,32,0,[]]}
};
text199.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 130px; min-height: 27px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 130px; min-height: 27px;\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\"><strong>Caller\'s voice.</strong>&nbsp;</span></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 32px; top: 125px; width: 130px; height: 27px; z-index: 16;",
	cssClasses:	"",
	id:		"199",
	htmlId:		"tobj199",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[32,125,130,27]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":32,"y":125,"width":130,"height":27},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text200.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 68px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 68px; min-height: 21px;\"><label for=\"rad201\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Female</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 153px; width: 68px; height: 21px; z-index: 17;",
	cssClasses:	"",
	id:		"200",
	htmlId:		"tobj200",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[57,153,68,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":153,"width":68,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox201.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad201\" name=\"rad201\" value=\"Female\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 154px; width: 19px; height: 19px; z-index: 18;",
	cssClasses:	"",
	id:		"201",
	htmlId:		"tobj201",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[27,154,19,19]],"desktopRect":{"x":27,"y":154,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text202.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 49px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 49px; min-height: 21px;\"><label for=\"rad203\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Male</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 181px; width: 49px; height: 21px; z-index: 19;",
	cssClasses:	"",
	id:		"202",
	htmlId:		"tobj202",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[57,181,49,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":181,"width":49,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox203.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad203\" name=\"rad203\" value=\"Male\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 182px; width: 19px; height: 19px; z-index: 20;",
	cssClasses:	"",
	id:		"203",
	htmlId:		"tobj203",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[27,182,19,19]],"desktopRect":{"x":27,"y":182,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text204.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 63px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 63px; min-height: 21px;\"><label for=\"rad205\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Accent</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 209px; width: 63px; height: 21px; z-index: 21;",
	cssClasses:	"",
	id:		"204",
	htmlId:		"tobj204",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[57,209,63,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":209,"width":63,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox205.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad205\" name=\"rad205\" value=\"Accent\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 210px; width: 19px; height: 19px; z-index: 22;",
	cssClasses:	"",
	id:		"205",
	htmlId:		"tobj205",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[27,210,19,19]],"desktopRect":{"x":27,"y":210,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text206.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 52px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 52px; min-height: 21px;\"><label for=\"rad207\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Calm</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 265px; width: 52px; height: 21px; z-index: 23;",
	cssClasses:	"",
	id:		"206",
	htmlId:		"tobj206",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 4 text"
	},
	objData:	{"a":[0,32,0,[57,265,52,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":265,"width":52,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox207.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad207\" name=\"rad207\" value=\"Calm\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 266px; width: 19px; height: 19px; z-index: 24;",
	cssClasses:	"",
	id:		"207",
	htmlId:		"tobj207",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 4 button"
	},
	objData:	{"a":[0,32,0,[27,266,19,19]],"desktopRect":{"x":27,"y":266,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text208.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 86px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 86px; min-height: 21px;\"><label for=\"rad209\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Disguised</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 293px; width: 86px; height: 21px; z-index: 25;",
	cssClasses:	"",
	id:		"208",
	htmlId:		"tobj208",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 5 text"
	},
	objData:	{"a":[0,32,0,[57,293,86,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":293,"width":86,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox209.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad209\" name=\"rad209\" value=\"Disguised\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 294px; width: 19px; height: 19px; z-index: 26;",
	cssClasses:	"",
	id:		"209",
	htmlId:		"tobj209",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 5 button"
	},
	objData:	{"a":[0,32,0,[27,294,19,19]],"desktopRect":{"x":27,"y":294,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text210.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 117px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 117px; min-height: 21px;\"><label for=\"rad211\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Clearing throat</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 321px; width: 117px; height: 21px; z-index: 27;",
	cssClasses:	"",
	id:		"210",
	htmlId:		"tobj210",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 6 text"
	},
	objData:	{"a":[0,32,0,[57,321,117,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":321,"width":117,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox211.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad211\" name=\"rad211\" value=\"Clearing throat\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 322px; width: 19px; height: 19px; z-index: 28;",
	cssClasses:	"",
	id:		"211",
	htmlId:		"tobj211",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 6 button"
	},
	objData:	{"a":[0,32,0,[27,322,19,19]],"desktopRect":{"x":27,"y":322,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text212.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 82px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 82px; min-height: 21px;\"><label for=\"rad213\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Coughing</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 349px; width: 82px; height: 21px; z-index: 29;",
	cssClasses:	"",
	id:		"212",
	htmlId:		"tobj212",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 7 text"
	},
	objData:	{"a":[0,32,0,[57,349,82,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":349,"width":82,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox213.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad213\" name=\"rad213\" value=\"Coughing\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 350px; width: 19px; height: 19px; z-index: 30;",
	cssClasses:	"",
	id:		"213",
	htmlId:		"tobj213",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 7 button"
	},
	objData:	{"a":[0,32,0,[27,350,19,19]],"desktopRect":{"x":27,"y":350,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text214.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 119px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 119px; min-height: 21px;\"><label for=\"rad215\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Cracking voice</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 377px; width: 119px; height: 21px; z-index: 31;",
	cssClasses:	"",
	id:		"214",
	htmlId:		"tobj214",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 8 text"
	},
	objData:	{"a":[0,32,0,[57,377,119,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":377,"width":119,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox215.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad215\" name=\"rad215\" value=\"Cracking voice\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 378px; width: 19px; height: 19px; z-index: 32;",
	cssClasses:	"",
	id:		"215",
	htmlId:		"tobj215",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 8 button"
	},
	objData:	{"a":[0,32,0,[27,378,19,19]],"desktopRect":{"x":27,"y":378,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text216.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 60px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 60px; min-height: 21px;\"><label for=\"rad217\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Crying</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 405px; width: 60px; height: 21px; z-index: 33;",
	cssClasses:	"",
	id:		"216",
	htmlId:		"tobj216",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 9 text"
	},
	objData:	{"a":[0,32,0,[57,405,60,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":405,"width":60,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox217.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad217\" name=\"rad217\" value=\"Crying\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 406px; width: 19px; height: 19px; z-index: 34;",
	cssClasses:	"",
	id:		"217",
	htmlId:		"tobj217",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 9 button"
	},
	objData:	{"a":[0,32,0,[27,406,19,19]],"desktopRect":{"x":27,"y":406,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text218.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 54px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 54px; min-height: 21px;\"><label for=\"rad219\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Deep</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 433px; width: 54px; height: 21px; z-index: 35;",
	cssClasses:	"",
	id:		"218",
	htmlId:		"tobj218",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 10 text"
	},
	objData:	{"a":[0,32,0,[57,433,54,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":433,"width":54,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox219.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad219\" name=\"rad219\" value=\"Deep\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 434px; width: 19px; height: 19px; z-index: 36;",
	cssClasses:	"",
	id:		"219",
	htmlId:		"tobj219",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 10 button"
	},
	objData:	{"a":[0,32,0,[27,434,19,19]],"desktopRect":{"x":27,"y":434,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text220.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 59px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 59px; min-height: 21px;\"><label for=\"rad221\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Raspy</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 461px; width: 59px; height: 21px; z-index: 37;",
	cssClasses:	"",
	id:		"220",
	htmlId:		"tobj220",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 11 text"
	},
	objData:	{"a":[0,32,0,[57,461,59,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":461,"width":59,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox221.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad221\" name=\"rad221\" value=\"Raspy\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 462px; width: 19px; height: 19px; z-index: 38;",
	cssClasses:	"",
	id:		"221",
	htmlId:		"tobj221",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 11 button"
	},
	objData:	{"a":[0,32,0,[27,462,19,19]],"desktopRect":{"x":27,"y":462,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text222.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 55px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 55px; min-height: 21px;\"><label for=\"rad223\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Angry</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 237px; width: 55px; height: 21px; z-index: 39;",
	cssClasses:	"",
	id:		"222",
	htmlId:		"tobj222",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 12 text"
	},
	objData:	{"a":[0,32,0,[57,237,55,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":237,"width":55,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox223.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad223\" name=\"rad223\" value=\"Angry\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 238px; width: 19px; height: 19px; z-index: 40;",
	cssClasses:	"",
	id:		"223",
	htmlId:		"tobj223",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 12 button"
	},
	objData:	{"a":[0,32,0,[27,238,19,19]],"desktopRect":{"x":27,"y":238,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text279.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 138px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 138px; min-height: 21px;\"><label for=\"rad280\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">none of the above</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 57px; top: 489px; width: 138px; height: 21px; z-index: 41;",
	cssClasses:	"",
	id:		"279",
	htmlId:		"tobj279",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 13 text"
	},
	objData:	{"a":[0,32,0,[57,489,138,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":57,"y":489,"width":138,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox280.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad280\" name=\"rad280\" value=\"none of the above\" onclick=\"qu194.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 27px; top: 490px; width: 19px; height: 19px; z-index: 42;",
	cssClasses:	"",
	id:		"280",
	htmlId:		"tobj280",
	bInsAnc:	0,
	fieldsetId:	'fset194',
	cwObj:		{
		"name":	"Choice 13 button"
	},
	objData:	{"a":[0,32,0,[27,490,19,19]],"desktopRect":{"x":27,"y":490,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
qu224.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu224",
	bInsAnc:	undefined,
	cwObj:		{
				"crLineColor":	"",
				"questType":	14,
				"dwQuestFlags":	1,
				"doImmFeedback":	0,
				"maxAllowedAttempts":	0,
				"arrAns":	["\\u0046\\u0061\\u0063\\u0074\\u006F\\u0072\\u0079\\u0020\\u004D\\u0061\\u0063\\u0068\\u0069\\u006E\\u0065"],
				"correctFeedbackFunc":	0,
				"incorrectFeedbackFunc":	0,
				"attemptsFeedbackFunc":	0,
				"varQuest":	VarQuestion_224
	},
	objData:	{"a":[0,32,0,[]]}
};
text229.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 144px; min-height: 21px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 144px; min-height: 21px;\"><p align=\"left\"><strong><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Background Noise</span></strong></p></div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 236px; top: 129px; width: 144px; height: 21px; z-index: 43;",
	cssClasses:	"",
	id:		"229",
	htmlId:		"tobj229",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[236,129,144,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":236,"y":129,"width":144,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text230.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 108px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 108px; min-height: 21px;\"><label for=\"rad231\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Animal Noise</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 157px; width: 108px; height: 21px; z-index: 44;",
	cssClasses:	"",
	id:		"230",
	htmlId:		"tobj230",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[264,157,108,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":157,"width":108,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox231.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad231\" name=\"rad231\" value=\"Animal Noise\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 156px; width: 19px; height: 19px; z-index: 45;",
	cssClasses:	"",
	id:		"231",
	htmlId:		"tobj231",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[234,156,19,19]],"desktopRect":{"x":234,"y":156,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text232.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 105px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 105px; min-height: 21px;\"><label for=\"rad233\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">House Noise</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 187px; width: 105px; height: 21px; z-index: 46;",
	cssClasses:	"",
	id:		"232",
	htmlId:		"tobj232",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[264,187,105,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":187,"width":105,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox233.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad233\" name=\"rad233\" value=\"House Noise\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 186px; width: 19px; height: 19px; z-index: 47;",
	cssClasses:	"",
	id:		"233",
	htmlId:		"tobj233",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[234,186,19,19]],"desktopRect":{"x":234,"y":186,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text234.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 102px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 102px; min-height: 21px;\"><label for=\"rad235\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Street Noise</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 217px; width: 102px; height: 21px; z-index: 48;",
	cssClasses:	"",
	id:		"234",
	htmlId:		"tobj234",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[264,217,102,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":217,"width":102,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox235.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad235\" name=\"rad235\" value=\"Street Noise\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 216px; width: 19px; height: 19px; z-index: 49;",
	cssClasses:	"",
	id:		"235",
	htmlId:		"tobj235",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[234,216,19,19]],"desktopRect":{"x":234,"y":216,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text236.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 89px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 89px; min-height: 21px;\"><label for=\"rad237\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">PA system</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 247px; width: 89px; height: 21px; z-index: 50;",
	cssClasses:	"",
	id:		"236",
	htmlId:		"tobj236",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 4 text"
	},
	objData:	{"a":[0,32,0,[264,247,89,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":247,"width":89,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox237.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad237\" name=\"rad237\" value=\"PA system\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 246px; width: 19px; height: 19px; z-index: 51;",
	cssClasses:	"",
	id:		"237",
	htmlId:		"tobj237",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 4 button"
	},
	objData:	{"a":[0,32,0,[234,246,19,19]],"desktopRect":{"x":234,"y":246,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text238.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 107px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 107px; min-height: 21px;\"><label for=\"rad239\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Conversation</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 277px; width: 107px; height: 21px; z-index: 52;",
	cssClasses:	"",
	id:		"238",
	htmlId:		"tobj238",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 5 text"
	},
	objData:	{"a":[0,32,0,[264,277,107,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":277,"width":107,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox239.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad239\" name=\"rad239\" value=\"Conversation\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 276px; width: 19px; height: 19px; z-index: 53;",
	cssClasses:	"",
	id:		"239",
	htmlId:		"tobj239",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 5 button"
	},
	objData:	{"a":[0,32,0,[234,276,19,19]],"desktopRect":{"x":234,"y":276,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text240.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 56px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 56px; min-height: 21px;\"><label for=\"rad241\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Music</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 307px; width: 56px; height: 21px; z-index: 54;",
	cssClasses:	"",
	id:		"240",
	htmlId:		"tobj240",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 6 text"
	},
	objData:	{"a":[0,32,0,[264,307,56,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":307,"width":56,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox241.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad241\" name=\"rad241\" value=\"Music\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 306px; width: 19px; height: 19px; z-index: 55;",
	cssClasses:	"",
	id:		"241",
	htmlId:		"tobj241",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 6 button"
	},
	objData:	{"a":[0,32,0,[234,306,19,19]],"desktopRect":{"x":234,"y":306,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text242.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 53px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 53px; min-height: 21px;\"><label for=\"rad243\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Clear</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 337px; width: 53px; height: 21px; z-index: 56;",
	cssClasses:	"",
	id:		"242",
	htmlId:		"tobj242",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 7 text"
	},
	objData:	{"a":[0,32,0,[264,337,53,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":337,"width":53,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox243.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad243\" name=\"rad243\" value=\"Clear\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 336px; width: 19px; height: 19px; z-index: 57;",
	cssClasses:	"",
	id:		"243",
	htmlId:		"tobj243",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 7 button"
	},
	objData:	{"a":[0,32,0,[234,336,19,19]],"desktopRect":{"x":234,"y":336,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text244.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 55px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 55px; min-height: 21px;\"><label for=\"rad245\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Static</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 367px; width: 55px; height: 21px; z-index: 58;",
	cssClasses:	"",
	id:		"244",
	htmlId:		"tobj244",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 8 text"
	},
	objData:	{"a":[0,32,0,[264,367,55,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":367,"width":55,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox245.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad245\" name=\"rad245\" value=\"Static\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 366px; width: 19px; height: 19px; z-index: 59;",
	cssClasses:	"",
	id:		"245",
	htmlId:		"tobj245",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 8 button"
	},
	objData:	{"a":[0,32,0,[234,366,19,19]],"desktopRect":{"x":234,"y":366,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text246.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 119px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 119px; min-height: 21px;\"><label for=\"rad247\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Office machine</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 397px; width: 119px; height: 21px; z-index: 60;",
	cssClasses:	"",
	id:		"246",
	htmlId:		"tobj246",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 9 text"
	},
	objData:	{"a":[0,32,0,[264,397,119,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":397,"width":119,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox247.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad247\" name=\"rad247\" value=\"Office machine\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 396px; width: 19px; height: 19px; z-index: 61;",
	cssClasses:	"",
	id:		"247",
	htmlId:		"tobj247",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 9 button"
	},
	objData:	{"a":[0,32,0,[234,396,19,19]],"desktopRect":{"x":234,"y":396,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text248.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 130px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 130px; min-height: 21px;\"><label for=\"rad249\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Factory Machine</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 427px; width: 130px; height: 21px; z-index: 62;",
	cssClasses:	"",
	id:		"248",
	htmlId:		"tobj248",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 10 text"
	},
	objData:	{"a":[0,32,0,[264,427,130,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":427,"width":130,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox249.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad249\" name=\"rad249\" value=\"Factory Machine\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 426px; width: 19px; height: 19px; z-index: 63;",
	cssClasses:	"",
	id:		"249",
	htmlId:		"tobj249",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 10 button"
	},
	objData:	{"a":[0,32,0,[234,426,19,19]],"desktopRect":{"x":234,"y":426,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
text284.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 138px; min-height: 21px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 138px; min-height: 21px;\"><label for=\"rad285\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">none of the above</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 264px; top: 457px; width: 138px; height: 21px; z-index: 64;",
	cssClasses:	"",
	id:		"284",
	htmlId:		"tobj284",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 11 text"
	},
	objData:	{"a":[0,32,0,[264,457,138,21]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":264,"y":457,"width":138,"height":21},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
checkbox285.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"checkbox\" id=\"rad285\" name=\"rad285\" value=\"none of the above\" onclick=\"qu224.questionUpdated(1);\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 234px; top: 456px; width: 19px; height: 19px; z-index: 65;",
	cssClasses:	"",
	id:		"285",
	htmlId:		"tobj285",
	bInsAnc:	0,
	fieldsetId:	'fset224',
	cwObj:		{
		"name":	"Choice 11 button"
	},
	objData:	{"a":[0,32,0,[234,456,19,19]],"desktopRect":{"x":234,"y":456,"width":19,"height":19},"formType":5,"dwFormFlags":0}
};
rcdObj.rcdData.att_Desktop = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"normal","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	8
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/image0000.png","images/arrow2_next.png","images/arrow2_back.png","images/home.png","images/btn2_exit1049.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-image: url("images/image0000.png"); visibility: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","url(images/image0000.png)",720,540,1];
