if (window.VarCurrentView) VarCurrentView.set('Desktop');
function init_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	if (!isOPAPub() || isLOPopup()) window.init_page();
	preload(rcdObj['preload_'+rcdObj.view]);
}
function defineFuncs_Desktop() {
	if ( rcdObj.view != 'Desktop' ) return;
	try{
		if (window.initGEV)
		{
		 initGEV(0,swipeLeft,swipeRight);

		}
		} catch(e) { if (window.console) window.console.log(e); }	pageClick = n;
	pageRClick = n;
	pageKey = n;
}
textbutton343.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj343inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_900_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1217&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 590px; top: 17px; width: 42px; height: 42px; z-index: 13; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"343",
	htmlId:		"tobj343",
	bInsAnc:	false,
	cwObj:		{
		"name":	"home",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page40.html',true,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[589.9999999999999,17.00000000000009,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":590,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1217\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1217&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1219\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1219&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1221\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1221&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1223\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/home.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1223&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"home","titleValue":"home"}
};
textbutton1050.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1050inner\"><svg viewBox=\"0 0 42 42\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(21 21)\" style=\"\">\n	<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_900_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1225&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(21 21)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 652px; top: 17px; width: 42px; height: 42px; z-index: 14; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1050",
	htmlId:		"tobj1050",
	bInsAnc:	false,
	cwObj:		{
		"name":	"btn2_exit",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkExitClose',actItem:function(){ {cleanupTitle('page1.html'); trivExitPage('ObjLayerActionExit()',false);} 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[651.9999999999999,17.00000000000009,42,42]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":652,"y":17,"width":42,"height":42},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1225\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1225&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1227\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1227&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1229\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1229&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(21 21)\" style=\"\">\n\t<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_40_1231\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"42\" height=\"42\" xlink:href=\"images/btn2_exit1049.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.5 0 L 31.5 0 A 10.5 10.5 0 0 1 42 10.5 L 42 31.5 A 10.5 10.5 0 0 1 31.5 42 L 10.5 42 A 10.5 10.5 0 0 1 0 31.5 L 0 10.5 A 10.5 10.5 0 0 1 10.5 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_40_1231&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-21, -21) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(21 21)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"btn2_exit","titleValue":"btn2_exit"}
};
shape64.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj64inner\"><svg viewBox=\"0 0 720 82\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(360 41)\" style=\"\">\n	<path d=\"M 0 0 L 720 0 L 720 82 L 0 82 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(200, 16, 46); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-360, -41) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(360 41)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 1.9611e-12px; width: 720px; height: 82px; z-index: 0; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"64",
	htmlId:		"tobj64",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 7"
	},
	objData:	{"a":[0,288,0,[0,1.9610979506978765e-12,720,82]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":720,"height":82},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 7","titleValue":"Rectangle 7"}
};
og72.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"og72",
	bInsAnc:	undefined,
	objData:	{"a":[0,32,0,[]],"bReadLast":false}
};
shape73.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj73inner\"><svg viewBox=\"0 0 683 77\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\"><g transform=\"translate(341.5 38.5)\" style=\"\">\n	<path d=\"M 0 0 L 683 0 L 683 77 L 0 77 L 0 0 Z\" style=\"stroke: rgb(1, 0, 0); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(200, 16, 46); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-341.5, -38.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(341.5 38.5)\">\n		<text font-family=\"Lucida Sans Unicode\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 0px; top: 1.27898e-12px; width: 683px; height: 77px; z-index: 1; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"73",
	htmlId:		"tobj73",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Rectangle 8"
	},
	objData:	{"a":[0,288,0,[0,1.2789769243681803e-12,683,77]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":0,"y":0,"width":683,"height":77},"bTriggerScreenRdrOnShow":false,"btnState":"disabled","altValue":"Rectangle 8","titleValue":"Rectangle 8"}
};
text188.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 350px; min-height: 35px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 340px; min-height: 25px;\"><h1><p align=\"left\"><span style=\"font-family: Verdana, sans-serif; color: rgb(255, 255, 255); font-size: 16pt;\"><span class='VarCurrentPageName'>" +  VarCurrentPageName.getValueForDisplay() + "</span></span></p></h1></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 19px; top: 29px; width: 350px; height: 35px; z-index: 15;",
	cssClasses:	"",
	id:		"188",
	htmlId:		"tobj188",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Title"
	},
	objData:	{"a":[0,96,0,[19,29,350,35]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":19,"y":29,"width":350,"height":35},"dwTextFlags":65536,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text893.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 128px; min-height: 29px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 118px; min-height: 19px;\"><p align=\"left\"><span style=\"color: rgb(255, 255, 255); font-family: \'Arial\',sans-serif; font-size: 12pt;\">Page</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 442px; top: 37px; width: 128px; height: 29px; z-index: 2;",
	cssClasses:	"",
	id:		"893",
	htmlId:		"tobj893",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Page Count",
		"arChld":
	[
		{type:6,on:11,delay:0,name:'Set label contents',actItem:function(){ text893.changeContents( "Page " +  VarPageInChapter.getValueForDisplay() + " of " +  VarPagesInChapter.getValueForDisplay() + "" ); 
    if(typeof pF == 'function') pF(); }},
		{type:6,on:11,delay:0,name:'Show',actItem:function(){ text893.show(); 
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[0,2080,0,[442,37,128,29]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":567,"y":37,"width":128,"height":29},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton1013.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1013inner\"><svg viewBox=\"0 0 41 41\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(20.5 20.5)\" style=\"\">\n	<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_900_899_1337\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1337&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(20.5 20.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 590px; top: 487px; width: 41px; height: 41px; z-index: 16; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1013",
	htmlId:		"tobj1013",
	bInsAnc:	false,
	cwObj:		{
		"name":	"test back",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkGoTo',actItem:function(){ trivExitPage('page969.html',false,false);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[590,487,41,41]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":590,"y":487,"width":41,"height":41},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1337\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1337&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1339\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1339&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1341\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1341&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1343\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/arrow2_back.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1343&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"test back","titleValue":"test back"}
};
textbutton921.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj921inner\"><svg viewBox=\"0 0 60 40\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(30 20)\" style=\"\">\n	<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(207, 42, 39); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_900_899_1353\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"60\" height=\"40\" xlink:href=\"images/black1_cancel_921_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1353&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(30 20)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 48px; top: 496px; width: 60px; height: 40px; z-index: 17; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"921",
	htmlId:		"tobj921",
	bInsAnc:	false,
	cwObj:		{
		"name":	"black1_cancel",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkCancTestSurv',actItem:function(){ cancelTest();
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,36960,0,[47.999999999999986,496,60,40]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":48,"y":166,"width":60,"height":40},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(30 20)\" style=\"\">\n\t<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(207, 42, 39); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1353\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"60\" height=\"40\" xlink:href=\"images/black1_cancel_921_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1353&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(30 20)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(30 20)\" style=\"\">\n\t<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1355\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"60\" height=\"40\" xlink:href=\"images/black1_cancel_921_over.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1355&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(30 20)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(30 20)\" style=\"\">\n\t<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(255, 255, 255); fill-opacity: 0; fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1357\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"60\" height=\"40\" xlink:href=\"images/black1_cancel_921_clicked.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1357&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(30 20)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(30 20)\" style=\"\">\n\t<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(207, 42, 39); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_899_1359\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"60\" height=\"40\" xlink:href=\"images/black1_cancel_921_normal.gif\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 0 0 L 60 0 L 60 40 L 0 40 L 0 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_899_1359&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-30, -20) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(30 20)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"black1_cancel","titleValue":"black1_cancel"}
};
text1021.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 200px; min-height: 67px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 5px; top: 5px; width: 190px; min-height: 57px;\"><p style=\"text-align:left\"><span style=\"font-family:Arial,sans-serif;font-size:12pt;color:#000000\">Click the check mark to submit your answers and grade the test.</span></p></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 493px; top: 394px; width: 200px; height: 67px; z-index: 3;",
	cssClasses:	"",
	id:		"1021",
	htmlId:		"tobj1021",
	bInsAnc:	0,
	cwObj:		{
		"name":	"Text Block 2"
	},
	objData:	{"a":[0,32,0,[493,394,200,67]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":493,"y":394,"width":200,"height":67},"dwTextFlags":0,"bgColor":"transparent","marginSize":5,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
textbutton1510.rcdData.att_Desktop = 
{
	innerHtml:	"<div id=\"tobj1510inner\"><svg viewBox=\"0 0 41 41\" preserveAspectRatio=\"none\" focusable=\"false\" style=\"pointer-events: none; left: 0px; top: 0px; width: 100%; height: 100%; position: absolute;\" aria-hidden=\"true\"><g transform=\"translate(20.5 20.5)\" style=\"\">\n	<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n	<pattern id=\"SVGID_900_1361\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/check_circle.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_1361&quot;); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100); pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n	<g transform=\"translate(20.5 20.5)\">\n		<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity:1;filter:alpha(opacity=100);\">\n			<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n		</text>\n	</g>\n</svg></div>",
	cssText:	"visibility: inherit; position: absolute; left: 651px; top: 486px; width: 41px; height: 41px; z-index: 18; cursor: pointer; overflow: visible; pointer-events: none;",
	cssClasses:	"",
	id:		"1510",
	htmlId:		"tobj1510",
	bInsAnc:	false,
	cwObj:		{
		"name":	"check_circle",
		"arChld":
	[
		{type:6,on:2,delay:0,name:'OnMClkProcTestSurv',actItem:function(){ processTest(1);
    if(typeof pF == 'function') pF(); }}
	]
	},
	objData:	{"a":[4,33120,0,[651,486,41,41]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":651,"y":486,"width":41,"height":41},"bTriggerScreenRdrOnShow":false,"svgDataNormal":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_1361\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/check_circle.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_1361&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataOver":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(183, 0, 0); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_1363\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/check_circle.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_1363&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDown":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(110, 12, 12); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_1365\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/check_circle.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_1365&quot;); fill-rule: nonzero; opacity: 1; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 1;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","svgDataDisabled":"<g transform=\"translate(20.5 20.5)\" style=\"\">\n\t<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0 Z\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: rgb(153, 0, 0); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n\t<pattern id=\"SVGID_900_1367\" x=\"0\" y=\"0\" width=\"1\" height=\"1\">\n<image x=\"0\" y=\"0\" width=\"41\" height=\"41\" xlink:href=\"images/check_circle.png\" preserveAspectRatio=\"none\"></image>\n</pattern>\n<path d=\"M 10.25 0 L 30.75 0 A 10.25 10.25 0 0 1 41 10.25 L 41 30.75 A 10.25 10.25 0 0 1 30.75 41 L 10.25 41 A 10.25 10.25 0 0 1 0 30.75 L 0 10.25 A 10.25 10.25 0 0 1 10.25 0\" style=\"stroke: rgb(9, 99, 177); stroke-width: 0; stroke-dasharray: none; stroke-linecap: round; stroke-linejoin: round; stroke-miterlimit: 10; fill: url(&quot;#SVGID_900_1367&quot;); fill-rule: nonzero; opacity: 0.6; pointer-events: auto;\" transform=\"translate(0 0) translate(-20.5, -20.5) \" stroke-linecap=\"round\"></path>\n</g>\n\t<g transform=\"translate(20.5 20.5)\">\n\t\t<text font-family=\"Arial,sans-serif\" font-size=\"15.9999996\" font-weight=\"normal\" style=\"stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-linejoin: miter; stroke-miterlimit: 10; fill: rgb(255,255,255); fill-rule: nonzero; opacity: 0.6;\">\n\t\t\t<tspan x=\"0\" y=\"5.04\" fill=\"#FFFFFF\"></tspan>\n\t\t</text>\n\t</g>\n","btnState":"enabled","altValue":"check_circle","titleValue":"check_circle"}
};
qu984.rcdData.att_Desktop = 
{
	innerHtml:	"",
	cssText:	"",
	cssClasses:	"",
	id:		"null",
	htmlId:		"qu984",
	bInsAnc:	undefined,
	cwObj:		{
				"crLineColor":	"",
				"questType":	2,
				"dwQuestFlags":	0,
				"doImmFeedback":	0,
				"maxAllowedAttempts":	0,
				"arrAns":	["\\u0049\\u006D\\u006D\\u0065\\u0064\\u0069\\u0061\\u0074\\u0065\\u006C\\u0079\\u0020\\u006C\\u0065\\u0074\\u0020\\u0073\\u0065\\u0063\\u0075\\u0072\\u0069\\u0074\\u0079\\u0020\\u006B\\u006E\\u006F\\u0077\\u0020\\u0061\\u006E\\u0064\\u0020\\u006C\\u0065\\u0061\\u0076\\u0065\\u0020\\u0074\\u0068\\u0065\\u0020\\u0061\\u0072\\u0065\\u0061\\u002E"],
				"correctFeedbackFunc":	0,
				"incorrectFeedbackFunc":	0,
				"attemptsFeedbackFunc":	0,
				"varQuest":	VarQuestion_984
	},
	objData:	{"a":[0,32,0,[]]}
};
text989.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 635px; min-height: 44px;\"><legend><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 635px; min-height: 44px;\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">You find a box outside of the door with wires hanging out of the side. What should you do? Please choose the best answer from the choices below.</span></p>\n</div></legend></div>",
	cssText:	"visibility: inherit; position: absolute; left: 38px; top: 110px; width: 635px; height: 44px; z-index: 4;",
	cssClasses:	"",
	id:		"989",
	htmlId:		"tobj989",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Question Text"
	},
	objData:	{"a":[0,32,0,[38,110,635,44]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":38,"y":110,"width":635,"height":44},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
text991.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 364px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 364px; min-height: 20px;\"><label for=\"rad992\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Cut as many wires as you see to disable a bomb.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 66px; top: 169px; width: 364px; height: 20px; z-index: 5;",
	cssClasses:	"",
	id:		"991",
	htmlId:		"tobj991",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 1 text"
	},
	objData:	{"a":[0,32,0,[66,169,364,20]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":66,"y":169,"width":364,"height":20},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio992.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad992\" name=\"rad984\" value=\"Cut as many wires as you see to disable a bomb.\" onclick=\"VarQuestion_984.set(this.value);qu984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 37px; top: 169px; width: 19px; height: 19px; z-index: 6;",
	cssClasses:	"",
	id:		"992",
	htmlId:		"tobj992",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 1 button"
	},
	objData:	{"a":[0,32,0,[37,169,19,19]],"desktopRect":{"x":37,"y":169,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
text993.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 283px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 283px; min-height: 20px;\"><label for=\"rad994\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Pick up the box and take it to security.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 66px; top: 199px; width: 283px; height: 20px; z-index: 7;",
	cssClasses:	"",
	id:		"993",
	htmlId:		"tobj993",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 2 text"
	},
	objData:	{"a":[0,32,0,[66,199,283,20]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":66,"y":199,"width":283,"height":20},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio994.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad994\" name=\"rad984\" value=\"Pick up the box and take it to security.\" onclick=\"VarQuestion_984.set(this.value);qu984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 37px; top: 199px; width: 19px; height: 19px; z-index: 8;",
	cssClasses:	"",
	id:		"994",
	htmlId:		"tobj994",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 2 button"
	},
	objData:	{"a":[0,32,0,[37,199,19,19]],"desktopRect":{"x":37,"y":199,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
text995.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 447px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 447px; min-height: 20px;\"><label for=\"rad996\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Cut only wires that are green or blue (never cut red or black). </span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 66px; top: 229px; width: 447px; height: 20px; z-index: 9;",
	cssClasses:	"",
	id:		"995",
	htmlId:		"tobj995",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 3 text"
	},
	objData:	{"a":[0,32,0,[66,229,447,20]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":66,"y":229,"width":447,"height":20},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio996.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad996\" name=\"rad984\" value=\"Cut only wires that are green or blue (never cut red or black). \" onclick=\"VarQuestion_984.set(this.value);qu984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 37px; top: 229px; width: 19px; height: 19px; z-index: 10;",
	cssClasses:	"",
	id:		"996",
	htmlId:		"tobj996",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 3 button"
	},
	objData:	{"a":[0,32,0,[37,229,19,19]],"desktopRect":{"x":37,"y":229,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
text997.rcdData.att_Desktop = 
{
	innerHtml:	"<div name=\"dCon\" style=\"position: absolute; left: 0px; top: 0px; width: 365px; min-height: 20px;\"><div name=\"dCon2\" class=\"ttxt\" style=\"left: 0px; top: 0px; width: 365px; min-height: 20px;\"><label for=\"rad998\" style=\"cursor:\"><p align=\"left\"><span style=\"font-family:Arial,sans-serif;color:#000000;font-size:12pt;\">Immediately let security know and leave the area.</span></p></label></div></div>",
	cssText:	"visibility: inherit; position: absolute; left: 66px; top: 259px; width: 365px; height: 20px; z-index: 11;",
	cssClasses:	"",
	id:		"997",
	htmlId:		"tobj997",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 4 text"
	},
	objData:	{"a":[0,32,0,[66,259,365,20]],"borderEffect":{"outline":0,"outlineColor":"#000000","borderWeight":0,"lineStyle":0,"borderColor":"#000000","borderRadius":"square"},"rotateEffect":{"angle":0,"anchorX":50,"anchorY":50},"desktopRect":{"x":66,"y":259,"width":365,"height":20},"dwTextFlags":0,"bgColor":"transparent","marginSize":0,"textPublishLang":"Inherit","bHideFromScrRdr":false,"bTriggerScreenRdrOnShow":false,"bTriggerScreenRdrOnShowDelay":0}
};
radio998.rcdData.att_Desktop = 
{
	innerHtml:	"<div style=\"white-space: nowrap; position: absolute; left: 0px; top: 0px; width: 19px; height: 19px;\"><input type=\"radio\" id=\"rad998\" name=\"rad984\" value=\"Immediately let security know and leave the area.\" onclick=\"VarQuestion_984.set(this.value);qu984.questionUpdated();\" style=\"cursor: pointer; background-image: url(&quot;images/trivantis-blank.gif&quot;);\"></div>",
	cssText:	"visibility: inherit; position: absolute; left: 37px; top: 259px; width: 19px; height: 19px; z-index: 12;",
	cssClasses:	"",
	id:		"998",
	htmlId:		"tobj998",
	bInsAnc:	0,
	fieldsetId:	'fset984',
	cwObj:		{
		"name":	"Choice 4 button"
	},
	objData:	{"a":[0,32,0,[37,259,19,19]],"desktopRect":{"x":37,"y":259,"width":19,"height":19},"formType":1,"dwFormFlags":0}
};
rcdObj.rcdData.att_Desktop = 
{
	font:	{"bold":0,"italic":0,"underline":0,"size":"12","color":null,"bgColor":null,"name":"Arial,sans-serif","lineHeight":"normal","marginTop":"0px","marginBottom":"0px"},
	pageIdx:	25
};
rcdObj.pgWidth_Desktop = pgWidth_desktop;
rcdObj.preload_Desktop = ["images/image0000.png","images/arrow2_back.png","images/home.png","images/black1_cancel_921_normal.gif","images/black1_cancel_921_over.gif","images/black1_cancel_921_clicked.gif","images/btn2_exit1049.png","images/check_circle.png"];
rcdObj.pgStyle_Desktop = 'position: absolute; left: 0px; top: 0px; width: 1009px; height: 662px; overflow: hidden; background-image: url("images/image0000.png"); visibility: hidden; background-size: auto;'
rcdObj.backgrd_Desktop = ["#FFFFFF","url(images/image0000.png)",720,540,1];
